﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GrillaExportarCrystal
{
    public partial class frmCompra : Form, ISeleccionProducto
    {
        public frmCompra()
        {
            InitializeComponent();
        }


        #region ISeleccionProducto Members

        public void AgregarProducto(DataGridViewRow row)
        {
            string desc = row.Cells["Descripcion"].Value.ToString(); 
            string precio = row.Cells["PrecioUnitario"].Value.ToString();

            this.dgvCompras.Rows.Add(new[] { desc, precio }); 
        }

        #endregion

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            frmProductos frm = new frmProductos();
            frm.ShowDialog(this);
        }

        private void dgvCompras_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            if(dgvCompras.Columns[e.ColumnIndex].Name == "Cantidad")
            {
                int valor;
                if (!int.TryParse(Convert.ToString(e.FormattedValue), out valor))
                {
                    dgvCompras.Rows[e.RowIndex].ErrorText = "La cantidad solo acepta valores numericos";
                    e.Cancel = true;
                }
            }
        }

        private void btnReporte_Click(object sender, EventArgs e)
        {
            dtCompra datos = GenerarFactura();

            frmVisorFactura frm = new frmVisorFactura(datos);
            frm.Show();
        }

        private dtCompra GenerarFactura()
        {
            dtCompra facturacion = new dtCompra();

            //
            // Agrego el registro con la info del cliente
            //
            dtCompra.DatosClienteRow rowDatosCliente = facturacion.DatosCliente.NewDatosClienteRow();
            rowDatosCliente.Nombre = txtNombre.Text;
            rowDatosCliente.Direccion = txtDireccion.Text;
            rowDatosCliente.Telefono = txtTelefono.Text;
            rowDatosCliente.DNI = txtDni.Text;

            facturacion.DatosCliente.AddDatosClienteRow(rowDatosCliente);

            //
            // Itero por cada fila del DataGridView creando el registro 
            // en el DataTable 
            //
            foreach (DataGridViewRow row in dgvCompras.Rows)
            {
                dtCompra.ComprasRow rowCompra = facturacion.Compras.NewComprasRow();  
                rowCompra.Descripcion = Convert.ToString(row.Cells["Descripcion"].Value);
                rowCompra.PrecioUnitario = Convert.ToInt32(row.Cells["PrecioUnitario"].Value);
                rowCompra.Cantidad = Convert.ToInt32(row.Cells["Cantidad"].Value);

                facturacion.Compras.AddComprasRow(rowCompra);
            }


            return facturacion;
        }
    }
}
