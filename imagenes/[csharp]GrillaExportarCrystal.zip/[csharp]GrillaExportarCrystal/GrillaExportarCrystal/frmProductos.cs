﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GrillaExportarCrystal
{
    public partial class frmProductos : Form
    {
        public frmProductos()
        {
            InitializeComponent();
        }

        private void dgvProductos_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            //
            // Se toma la fila a la cual se le ha realizado el doble click
            //
            DataGridViewRow row = this.dgvProductos.Rows[e.RowIndex];

            //
            // Se castea el form que se definio como owner al moento de hacer el ShowDialog()
            // el cual implementa la interfaz ISeleccionProducto
            //
            ISeleccionProducto parent = this.Owner as ISeleccionProducto;
            parent.AgregarProducto(row);

            this.Close();
        }

        private void Productos_Load(object sender, EventArgs e)
        {
            dgvProductos.AutoGenerateColumns = false;
            dgvProductos.DataSource = ObtenerProductos();
        }

        private ProductosDataSet.ProductosDataTable ObtenerProductos()
        {
            //
            // Se carga en el DataTable la lista de productos
            //
            ProductosDataSet.ProductosDataTable dtProductos = new ProductosDataSet.ProductosDataTable();

            ProductosDataSetTableAdapters.ProductosTableAdapter tableAdapter = new ProductosDataSetTableAdapters.ProductosTableAdapter();
            tableAdapter.Fill(dtProductos);

            return dtProductos;
        }
    }
}
