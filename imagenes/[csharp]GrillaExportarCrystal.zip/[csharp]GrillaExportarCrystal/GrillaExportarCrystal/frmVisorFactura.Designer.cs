﻿namespace GrillaExportarCrystal
{
    partial class frmVisorFactura
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.crwFactura = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.SuspendLayout();
            // 
            // crwFactura
            // 
            this.crwFactura.ActiveViewIndex = -1;
            this.crwFactura.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crwFactura.Dock = System.Windows.Forms.DockStyle.Fill;
            this.crwFactura.Location = new System.Drawing.Point(0, 0);
            this.crwFactura.Name = "crwFactura";
            this.crwFactura.SelectionFormula = "";
            this.crwFactura.Size = new System.Drawing.Size(548, 494);
            this.crwFactura.TabIndex = 0;
            this.crwFactura.ViewTimeSelectionFormula = "";
            // 
            // frmVisorFactura
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(548, 494);
            this.Controls.Add(this.crwFactura);
            this.Name = "frmVisorFactura";
            this.Text = "VisorFactura";
            this.Load += new System.EventHandler(this.frmVisorFactura_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private CrystalDecisions.Windows.Forms.CrystalReportViewer crwFactura;
    }
}