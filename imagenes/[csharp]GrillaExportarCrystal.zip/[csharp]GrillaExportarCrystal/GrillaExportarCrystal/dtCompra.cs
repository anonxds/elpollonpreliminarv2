﻿namespace GrillaExportarCrystal {
    
    
    public partial class dtCompra {
    }
}
namespace GrillaExportarCrystal.dtCompraTableAdapters
{
    
    
    public partial class dtCompra {
    }
}
