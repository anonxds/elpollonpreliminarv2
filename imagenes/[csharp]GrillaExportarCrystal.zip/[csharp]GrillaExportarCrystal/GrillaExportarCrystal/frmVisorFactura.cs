﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GrillaExportarCrystal
{
    public partial class frmVisorFactura : Form
    {
        dtCompra _datosreporte;

        private frmVisorFactura()
        {
            InitializeComponent();
        }

        public frmVisorFactura(dtCompra datos): this()
        {
            _datosreporte = datos;
        }

        private void frmVisorFactura_Load(object sender, EventArgs e)
        {
            Factura _factura = new Factura();
            _factura.SetDataSource(_datosreporte);

            crwFactura.ReportSource = _factura;
        }
    }
}
